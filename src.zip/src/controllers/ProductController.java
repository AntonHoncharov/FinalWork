package controllers;

import models.Product;
import utils.Validator;
import views.SalesView;

import java.util.Scanner;

// Controller
public class ProductController {

    Product model;
    SalesView view;

    // Конструктор
    public ProductController(Product model, SalesView view) {
        this.model = model;
        this.view = view;
    }


    public void runApp() {

        view.getInputs();
        Product product = new Product();
        Scanner scanner = new Scanner(System.in);


        // Здесь, реализуйте:
        // 1) получение имени товара через модель;
        product.setName(Validator.validateName(scanner));

        Validator.validateName(scanner);
        int quantity = Validator.validateQuantityInput(scanner);
        double price = Validator.validatePriceInput(scanner);


        double income = product.incomeCalculation(quantity, price);
        System.out.println(income);

        double netIncome = product.incomeCalculation(income, product.getTaxRate());
        System.out.println(netIncome);

        double incomeTax = product.taxCalculation(income, netIncome);
        System.out.println(incomeTax);


        // 2) вызов методов расчетов доходов и налога;


        // 3) округление расчетных значений;


        // 4) вывод расчетов по заданному формату.


        String output = "[здесь должен быть вывод по формату]";

        view.getOutput(output);
    }


}
