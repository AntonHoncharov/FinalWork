package utils;

public class Rounder {

    //содержащий статический метод округления значений.
    public static double rounding(double income) {
        return Math.ceil(income);

    }
}
