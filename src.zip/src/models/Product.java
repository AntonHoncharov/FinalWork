package models;


import base.Fiscal;
import base.Income;

// Model.

// Примените интерфейсы Income, Fiscal, переопределите их методы. // +
public class Product implements Income, Fiscal {

    // Объявление полей модели
    private String name;
    private int quantity;
    private double price;
    private final double taxRate = 0.05;
    // Налоговоу ставку объявите в виде константы
    // здесь ... // +






    public String getName(String name) {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public double getTaxRate() {
        return taxRate;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setPrice(double price) {
        this.price = price;
    }
// Обеспечьте доступ к полям модели через getters и setters
    // здесь ... // +


    // Переопределите методы реализуемых интерфейсов.


    // Расчёт дохода от продаж, до уплаты налога.
    // здесь ...  берем из фискал


    @Override
    public double incomeCalculation(int quantity, double price) {
        double income = quantity * price;
        return income;
    }


    // Расчёт суммы налога с продаж.
    // здесь ...берем из Инком

    @Override
    public double taxCalculation( double income,double netIncome) {
        double tax = income - netIncome;
        return tax;
    }


    // Расчёт чистого дохода, после уплаты налога.
    // здесь ... берем из фискал

    @Override
    public double incomeCalculation(double income, double taxRate) {
        double netIncome = income * taxRate;
        return netIncome;
    }


}
