package base;

import java.text.DecimalFormat;

public interface Fiscal {

    //  содержит абстрактный метод необходимости расчета налога от дохода

    // налог=доход-доход с вычетом налога

    double taxCalculation(double income,double netIncome);



}
