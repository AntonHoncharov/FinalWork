package base;

public interface Income {

    // содержит 2 перегруженных абстрактных метода
    //необходимости расчета дохода и чистого дохода


    // доход = колличество * цена

    // чистый доход = доход - налог


    double incomeCalculation(int quantity, double price);

    double incomeCalculation(double income, double tax);




}
