import controllers.ProductController;
import models.Product;
import views.SalesView;

// Входная точка в программу/приложение
public class App {

    public static void main(String[] args) {


        // Здесь создайте экземпляры Model, View и Controller,
        // на основании соответствующих конструкторов.
        Product product = new Product();

        SalesView salesView = new SalesView(product);
        ProductController productController = new ProductController(product, salesView);
        // Запуск программы/приложения.
        // Раскомментированный код будет корректным после
        // правильной настройки приложения
        productController.runApp();
    }
}
